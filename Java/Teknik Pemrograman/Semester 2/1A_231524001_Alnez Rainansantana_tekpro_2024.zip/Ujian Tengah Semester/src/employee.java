public class employee {
    
    private double salary;
    private String jabatan;
    private int tahunBekerja;

    public double getSalary(){
        return salary;
    }

    public void setSalary(double salary){
        this.salary = salary;
    }

    public String getJabatan(){
        return jabatan;
    }

    public void setJabatan(String jabatan){
        this.jabatan = jabatan;
    }

    public int getTahunBekerja(){
        return tahunBekerja;
    }

    public void setTahunBekerja(int tahunBekerja){
        this.tahunBekerja = tahunBekerja;
    }
}
