public interface koperasi {

    double loanMonthly();
}
